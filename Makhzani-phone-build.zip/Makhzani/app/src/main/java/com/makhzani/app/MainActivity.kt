package com.makhzani.app

import android.content.Context
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

// ---------- أدوات مساعدة ----------
fun norm(s: String): String = s.map {
    when (it) {
        in '٠'..'٩' -> '0' + (it - '٠')
        in '۰'..'۹' -> '0' + (it - '۰')
        '٫', '،' -> '.'
        else -> it
    }
}.joinToString("").trim()

fun fmt(d: Double): String = if (d % 1.0 == 0.0) d.toLong().toString() else String.format(Locale.US, "%.2f", d)
fun dateStr(t: Long): String = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(t))
fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_LONG).show()

fun parseProduct(id: Long, name: String, q: String, b: String, s: String, c: String): Pair<Product?, String?> {
    val qty = norm(q).toIntOrNull() ?: return null to "الكمية غير صحيحة"
    val buy = norm(b).toDoubleOrNull() ?: return null to "سعر الشراء غير صحيح"
    val sell = norm(s).toDoubleOrNull() ?: return null to "سعر البيع غير صحيح"
    if (qty < 0) return null to "الكمية لا يمكن أن تكون سالبة"
    if (!buy.isFinite() || !sell.isFinite() || buy < 0 || sell < 0) return null to "الأسعار غير صحيحة"
    if (name.isBlank()) return null to "اسم المنتج مطلوب"
    return Product(id, name.trim(), qty, buy, sell, c.trim()) to null
}

object Printer {
    private var wv: WebView? = null
    fun print(ctx: Context, title: String, body: String) {
        val html = "<html dir='rtl'><head><meta charset='utf-8'><style>@page{size:A4;margin:15mm}" +
            "body{font-family:sans-serif;direction:rtl}table{width:100%;border-collapse:collapse}" +
            "th,td{border:1px solid #444;padding:6px;text-align:right}th{background:#eee}</style></head><body>$body</body></html>"
        val w = WebView(ctx)
        wv = w
        var done = false
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, u: String) {
                if (done) return
                done = true
                val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
                pm.print(title, v.createPrintDocumentAdapter(title),
                    PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build())
            }
        }
        w.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }
}

fun receiptHtml(id: Long, date: Long, lines: List<ReceiptLine>): String {
    val rows = lines.joinToString("") { "<tr><td>${esc(it.productName)}</td><td>${it.qty}</td></tr>" }
    return "<h2 style='text-align:center'>وصل شراء</h2><p>رقم الوصل: $id &nbsp;&nbsp; التاريخ: ${dateStr(date)}</p>" +
        "<table><tr><th>اسم المنتج</th><th>الكمية المطلوبة</th></tr>$rows</table>"
}

// ---------- مكونات مشتركة ----------
@Composable
fun Cell(text: String, w: Dp, bold: Boolean = false, onClick: (() -> Unit)? = null) {
    Box(Modifier.width(w).then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(8.dp)) {
        Text(text, fontSize = 14.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun EditCell(v: String, w: Dp, num: Boolean, onChange: (String) -> Unit) {
    BasicTextField(
        value = v, onValueChange = onChange, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = if (num) KeyboardType.Decimal else KeyboardType.Text),
        textStyle = TextStyle(fontSize = 14.sp, color = Color.Black),
        modifier = Modifier.width(w).padding(4.dp).border(1.dp, Color.Gray, RoundedCornerShape(4.dp)).padding(6.dp)
    )
}

@Composable
fun Confirm(msg: String, onYes: () -> Unit, onNo: () -> Unit) = AlertDialog(
    onDismissRequest = onNo, text = { Text(msg) },
    confirmButton = { TextButton(onYes) { Text("نعم") } },
    dismissButton = { TextButton(onNo) { Text("إلغاء") } }
)

@Composable
fun ProductPicker(products: List<Product>, selected: Long?, onSelect: (Product) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text(products.find { it.id == selected }?.name ?: "اختر منتجاً", maxLines = 1)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            if (products.isEmpty()) DropdownMenuItem(text = { Text("لا توجد منتجات") }, onClick = { open = false })
            products.forEach { p -> DropdownMenuItem(text = { Text(p.name) }, onClick = { open = false; onSelect(p) }) }
        }
    }
}

// ---------- التطبيق ----------
@Composable
fun App() {
    val ctx = LocalContext.current
    val db = remember { AppDb.get(ctx) }
    val dao = remember { db.dao() }
    var tab by remember { mutableIntStateOf(0) }
    val labels = listOf("المنتجات", "وصل شراء", "إضافة سلع", "الوصولات", "السجل")
    val icons = listOf("📦", "🧾", "➕", "📂", "📜")
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF2E7D6B), background = Color(0xFFF7F9F8), surface = Color.White)) {
            Scaffold(
                containerColor = Color(0xFFF7F9F8),
                bottomBar = {
                    NavigationBar(containerColor = Color.White) {
                        labels.forEachIndexed { i, t ->
                            NavigationBarItem(selected = tab == i, onClick = { tab = i },
                                icon = { Text(icons[i], fontSize = 20.sp) },
                                label = { Text(t, fontSize = 11.sp, maxLines = 1) })
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when (tab) {
                        0 -> ProductsScreen(dao)
                        1 -> ReceiptScreen(dao, db)
                        2 -> AddStockScreen(dao)
                        3 -> ReceiptsListScreen(dao)
                        else -> AdditionsLogScreen(dao)
                    }
                }
            }
        }
    }
}

// ---------- المنتجات ----------
@Composable
fun ProductsScreen(dao: AppDao) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val all by remember(dao) { dao.products() }.collectAsState(initial = emptyList())
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("") }
    var sortKey by remember { mutableIntStateOf(0) }
    var asc by remember { mutableStateOf(true) }
    var editId by remember { mutableStateOf<Long?>(null) }
    var eName by remember { mutableStateOf("") }
    var eQty by remember { mutableStateOf("") }
    var eBuy by remember { mutableStateOf("") }
    var eSell by remember { mutableStateOf("") }
    var eCat by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var delP by remember { mutableStateOf<Product?>(null) }
    var catMenu by remember { mutableStateOf(false) }

    val cats = all.map { it.category }.filter { it.isNotBlank() }.distinct().sorted()
    val cmp: Comparator<Product> = when (sortKey) {
        0 -> compareBy<Product> { it.name.lowercase() }
        1 -> compareBy<Product> { it.qty }
        2 -> compareBy<Product> { it.buyPrice }
        3 -> compareBy<Product> { it.sellPrice }
        else -> compareBy<Product> { it.category.lowercase() }
    }
    val shown = all.filter { it.name.contains(q.trim(), true) && (cat.isEmpty() || it.category == cat) }
        .sortedWith(if (asc) cmp else cmp.reversed())

    val tw = 680.dp
    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Text("المنتجات", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(4.dp))
        OutlinedTextField(q, { q = it }, label = { Text("بحث باسم المنتج") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                OutlinedButton(onClick = { catMenu = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (cat.isEmpty()) "كل الأصناف" else cat, maxLines = 1, fontSize = 13.sp)
                }
                DropdownMenu(expanded = catMenu, onDismissRequest = { catMenu = false }) {
                    DropdownMenuItem(text = { Text("كل الأصناف") }, onClick = { cat = ""; catMenu = false })
                    cats.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { cat = c; catMenu = false }) }
                }
            }
            Button(onClick = { showAdd = true }, enabled = editId == null) { Text("إضافة منتج", fontSize = 13.sp) }
            Button(onClick = {
                val rows = shown.joinToString("") {
                    "<tr><td>${esc(it.name)}</td><td>${it.qty}</td><td>${fmt(it.buyPrice)}</td><td>${fmt(it.sellPrice)}</td><td>${esc(it.category)}</td></tr>"
                }
                Printer.print(ctx, "قائمة المخزون",
                    "<h2 style='text-align:center'>قائمة المخزون</h2><p>تاريخ الطباعة: ${dateStr(System.currentTimeMillis())}</p>" +
                        "<table><tr><th>اسم المنتج</th><th>الكمية</th><th>سعر الشراء</th><th>سعر البيع</th><th>الصنف</th></tr>$rows</table>")
            }) { Text("طباعة المخزون", fontSize = 13.sp) }
        }
        Spacer(Modifier.height(6.dp))
        Column(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
            val titles = listOf("اسم المنتج", "الكمية المتوفرة", "سعر الشراء", "سعر البيع", "الصنف")
            val ws = listOf(140.dp, 90.dp, 90.dp, 90.dp, 110.dp)
            Row(Modifier.background(Color(0xFFDDEDE8))) {
                titles.forEachIndexed { i, t ->
                    Cell(t + if (sortKey == i) (if (asc) " ▲" else " ▼") else "", ws[i], true) {
                        if (sortKey == i) asc = !asc else { sortKey = i; asc = true }
                    }
                }
                Cell("العمليات", 130.dp, true)
            }
            if (shown.isEmpty()) Text("لا توجد منتجات", Modifier.padding(16.dp))
            LazyColumn {
                items(shown, key = { it.id }) { p ->
                    val editing = editId == p.id
                    Row(Modifier.background(if (editing) Color(0xFFFFF8E1) else Color.White), verticalAlignment = Alignment.CenterVertically) {
                        if (editing) {
                            EditCell(eName, 140.dp, false) { eName = it }
                            EditCell(eQty, 90.dp, true) { eQty = it }
                            EditCell(eBuy, 90.dp, true) { eBuy = it }
                            EditCell(eSell, 90.dp, true) { eSell = it }
                            EditCell(eCat, 110.dp, false) { eCat = it }
                            Row(Modifier.width(130.dp)) {
                                TextButton(contentPadding = PaddingValues(4.dp), onClick = {
                                    scope.launch {
                                        try {
                                            val (pr, err) = parseProduct(p.id, eName, eQty, eBuy, eSell, eCat)
                                            val e = err ?: dao.saveProduct(pr!!)
                                            if (e != null) toast(ctx, e) else editId = null
                                        } catch (e: Exception) {
                                            toast(ctx, e.message ?: "تعذر حفظ التعديل")
                                        }
                                    }
                                }) { Text("تأكيد", fontSize = 13.sp) }
                                TextButton(contentPadding = PaddingValues(4.dp), onClick = { editId = null }) { Text("إلغاء", fontSize = 13.sp) }
                            }
                        } else {
                            Cell(p.name, 140.dp); Cell(p.qty.toString(), 90.dp); Cell(fmt(p.buyPrice), 90.dp)
                            Cell(fmt(p.sellPrice), 90.dp); Cell(p.category, 110.dp)
                            Row(Modifier.width(130.dp)) {
                                TextButton(contentPadding = PaddingValues(4.dp), enabled = editId == null, onClick = {
                                    editId = p.id; eName = p.name; eQty = p.qty.toString(); eBuy = fmt(p.buyPrice)
                                    eSell = fmt(p.sellPrice); eCat = p.category
                                }) { Text("تعديل", fontSize = 13.sp) }
                                TextButton(contentPadding = PaddingValues(4.dp), enabled = editId == null, onClick = { delP = p }) {
                                    Text("حذف", fontSize = 13.sp, color = Color(0xFFC62828))
                                }
                            }
                        }
                    }
                    HorizontalDivider(Modifier.width(tw))
                }
            }
        }
    }
    if (showAdd) AddProductDialog(dao) { showAdd = false }
    delP?.let { p ->
        Confirm("هل تريد حذف المنتج «${p.name}»؟ لن تُحذف السجلات التاريخية المرتبطة به.",
            { scope.launch { dao.deleteProduct(p.id); delP = null } }, { delP = null })
    }
}

@Composable
fun AddProductDialog(dao: AppDao, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var n by remember { mutableStateOf("") }
    var q by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var s by remember { mutableStateOf("") }
    var c by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text("إضافة منتج") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(n, { n = it }, label = { Text("اسم المنتج") }, singleLine = true)
                OutlinedTextField(q, { q = it }, label = { Text("الكمية") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(b, { b = it }, label = { Text("سعر الشراء") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(s, { s = it }, label = { Text("سعر البيع") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(c, { c = it }, label = { Text("الصنف") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    try {
                        val (pr, err) = parseProduct(0, n, q, b, s, c)
                        val e = err ?: dao.saveProduct(pr!!)
                        if (e != null) toast(ctx, e) else onDone()
                    } catch (e: Exception) {
                        toast(ctx, e.message ?: "تعذر حفظ المنتج")
                    }
                }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onDone) { Text("إلغاء") } }
    )
}

// ---------- وصل شراء ----------
class RLine(val key: Int) {
    var pid by mutableStateOf<Long?>(null)
    var qty by mutableStateOf("")
}

@Composable
fun ReceiptScreen(dao: AppDao, db: AppDb) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val products by remember(dao) { dao.products() }.collectAsState(initial = emptyList())
    val sorted = products.sortedBy { it.name.lowercase() }
    var counter by remember { mutableIntStateOf(1) }
    val lines = remember { mutableStateListOf(RLine(0)) }
    var no by remember { mutableLongStateOf(1) }
    var refresh by remember { mutableIntStateOf(0) }
    LaunchedEffect(refresh) { no = withContext(Dispatchers.IO) { db.nextReceiptNo() } }

    fun save(print: Boolean) {
        val items = ArrayList<Pair<String, Int>>()
        for (l in lines) {
            if (l.pid == null && l.qty.isBlank()) continue
            val p = products.find { it.id == l.pid }
            val q = norm(l.qty).toIntOrNull()
            if (p == null || q == null || q <= 0) { toast(ctx, "تحقق من الأسطر: اختر المنتج وأدخل كمية أكبر من صفر"); return }
            items.add(p.name to q)
        }
        if (items.isEmpty()) { toast(ctx, "لا يمكن حفظ وصل فارغ"); return }
        scope.launch {
            try {
                val date = System.currentTimeMillis()
                val id = dao.saveReceipt(date, items)
                if (print) Printer.print(ctx, "وصل شراء $id", receiptHtml(id, date, items.map { ReceiptLine(receiptId = id, productName = it.first, qty = it.second) }))
                lines.clear(); lines.add(RLine(counter++))
                refresh++
                toast(ctx, "تم حفظ الوصل رقم $id")
            } catch (e: Exception) {
                toast(ctx, e.message ?: "تعذر حفظ الوصل")
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Text("وصل شراء", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(4.dp))
        Text("رقم الوصل: $no      التاريخ: ${dateStr(System.currentTimeMillis())}", modifier = Modifier.padding(4.dp))
        Row(Modifier.fillMaxWidth().background(Color(0xFFDDEDE8)).padding(8.dp)) {
            Text("اسم المنتج", Modifier.weight(1f), fontWeight = FontWeight.Bold)
            Text("الكمية المطلوبة", Modifier.width(110.dp), fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(56.dp))
        }
        LazyColumn(Modifier.weight(1f)) {
            items(lines, key = { it.key }) { l ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    ProductPicker(sorted, l.pid, { l.pid = it.id }, Modifier.weight(1f))
                    OutlinedTextField(l.qty, { l.qty = it }, singleLine = true, modifier = Modifier.width(110.dp).padding(horizontal = 4.dp),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    TextButton(onClick = { lines.remove(l); if (lines.isEmpty()) lines.add(RLine(counter++)) }, contentPadding = PaddingValues(4.dp)) {
                        Text("حذف", color = Color(0xFFC62828), fontSize = 13.sp)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { lines.add(RLine(counter++)) }, modifier = Modifier.weight(1f)) { Text("إضافة سطر", fontSize = 13.sp) }
            Button(onClick = { save(false) }, modifier = Modifier.weight(1f)) { Text("حفظ", fontSize = 13.sp) }
            Button(onClick = { save(true) }, modifier = Modifier.weight(1f)) { Text("حفظ وطباعة", fontSize = 13.sp) }
        }
    }
}

// ---------- إضافة سلع للمخزن ----------
class ALine(val key: Int) {
    var pid by mutableStateOf<Long?>(null)
    var qty by mutableStateOf("")
    var buy by mutableStateOf("")
    var sell by mutableStateOf("")
}

@Composable
fun AddStockScreen(dao: AppDao) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val products by remember(dao) { dao.products() }.collectAsState(initial = emptyList())
    val sorted = products.sortedBy { it.name.lowercase() }
    var counter by remember { mutableIntStateOf(1) }
    val lines = remember { mutableStateListOf(ALine(0)) }

    fun confirm() {
        val out = ArrayList<AddLine>()
        for (l in lines) {
            if (l.pid == null && l.qty.isBlank()) continue
            val p = products.find { it.id == l.pid }
            if (p == null) { toast(ctx, "اختر منتجاً لكل سطر"); return }
            val q = norm(l.qty).toIntOrNull()
            if (q == null || q <= 0) { toast(ctx, "الكمية المضافة يجب أن تكون أكبر من صفر"); return }
            val b = if (l.buy.isBlank()) p.buyPrice else norm(l.buy).toDoubleOrNull()
            val s = if (l.sell.isBlank()) p.sellPrice else norm(l.sell).toDoubleOrNull()
            if (b == null || s == null || !b.isFinite() || !s.isFinite() || b < 0 || s < 0) { toast(ctx, "الأسعار غير صحيحة"); return }
            out.add(AddLine(p.id, q, b, s))
        }
        if (out.isEmpty()) { toast(ctx, "لا توجد سلع للإضافة"); return }
        scope.launch {
            try {
                dao.confirmAdditions(out, System.currentTimeMillis())
                lines.clear(); lines.add(ALine(counter++))
                toast(ctx, "تمت إضافة السلع إلى المخزن بنجاح")
            } catch (e: Exception) {
                toast(ctx, e.message ?: "تعذر تنفيذ العملية، لم يتم تغيير أي شيء")
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Text("إضافة سلع للمخزن", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(4.dp))
        Column(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
            Row(Modifier.background(Color(0xFFDDEDE8))) {
                Cell("اسم المنتج", 170.dp, true); Cell("الكمية المضافة", 100.dp, true)
                Cell("سعر الشراء", 90.dp, true); Cell("سعر البيع", 90.dp, true); Cell("الحالي (شراء/بيع)", 120.dp, true)
            }
            LazyColumn {
                items(lines, key = { it.key }) { l ->
                    val cur = products.find { it.id == l.pid }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ProductPicker(sorted, l.pid, { p -> l.pid = p.id; l.buy = fmt(p.buyPrice); l.sell = fmt(p.sellPrice) }, Modifier.width(170.dp).padding(2.dp))
                        EditCell(l.qty, 100.dp, true) { l.qty = it }
                        EditCell(l.buy, 90.dp, true) { l.buy = it }
                        EditCell(l.sell, 90.dp, true) { l.sell = it }
                        Cell(if (cur == null) "-" else "${fmt(cur.buyPrice)} / ${fmt(cur.sellPrice)}", 120.dp)
                        TextButton(onClick = { lines.remove(l); if (lines.isEmpty()) lines.add(ALine(counter++)) }, contentPadding = PaddingValues(4.dp)) {
                            Text("حذف", color = Color(0xFFC62828), fontSize = 13.sp)
                        }
                    }
                    HorizontalDivider(Modifier.width(680.dp))
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { lines.add(ALine(counter++)) }, modifier = Modifier.weight(1f)) { Text("إضافة سطر") }
            Button(onClick = { confirm() }, modifier = Modifier.weight(1f)) { Text("تأكيد الإضافة") }
        }
    }
}

// ---------- الوصولات السابقة ----------
@Composable
fun ReceiptsListScreen(dao: AppDao) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val rows by remember(dao) { dao.receipts() }.collectAsState(initial = emptyList())
    var view by remember { mutableStateOf<Pair<ReceiptRow, List<ReceiptLine>>?>(null) }
    var del by remember { mutableStateOf<ReceiptRow?>(null) }

    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Text("الوصولات السابقة", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(4.dp))
        Column(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
            Row(Modifier.background(Color(0xFFDDEDE8))) {
                Cell("رقم الوصل", 80.dp, true); Cell("التاريخ", 140.dp, true); Cell("عدد المنتجات", 100.dp, true)
                Cell("عرض", 60.dp, true); Cell("طباعة", 60.dp, true); Cell("حذف", 60.dp, true)
            }
            if (rows.isEmpty()) Text("لا توجد وصولات محفوظة", Modifier.padding(16.dp))
            LazyColumn {
                items(rows, key = { it.id }) { r ->
                    Row(Modifier.background(Color.White), verticalAlignment = Alignment.CenterVertically) {
                        Cell(r.id.toString(), 80.dp); Cell(dateStr(r.date), 140.dp); Cell(r.cnt.toString(), 100.dp)
                        TextButton(onClick = { scope.launch { view = r to dao.lines(r.id) } }, modifier = Modifier.width(60.dp), contentPadding = PaddingValues(2.dp)) { Text("عرض", fontSize = 13.sp) }
                        TextButton(onClick = { scope.launch { Printer.print(ctx, "وصل شراء ${r.id}", receiptHtml(r.id, r.date, dao.lines(r.id))) } }, modifier = Modifier.width(60.dp), contentPadding = PaddingValues(2.dp)) { Text("طباعة", fontSize = 13.sp) }
                        TextButton(onClick = { del = r }, modifier = Modifier.width(60.dp), contentPadding = PaddingValues(2.dp)) { Text("حذف", fontSize = 13.sp, color = Color(0xFFC62828)) }
                    }
                    HorizontalDivider(Modifier.width(500.dp))
                }
            }
        }
    }
    view?.let { (r, ls) ->
        AlertDialog(
            onDismissRequest = { view = null },
            title = { Text("وصل رقم ${r.id}") },
            text = {
                Column {
                    Text("التاريخ: ${dateStr(r.date)}", Modifier.padding(bottom = 8.dp))
                    ls.forEach { l ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                            Text(l.productName, Modifier.weight(1f)); Text(l.qty.toString())
                        }
                        HorizontalDivider()
                    }
                }
            },
            confirmButton = { TextButton({ view = null }) { Text("إغلاق") } }
        )
    }
    del?.let { r ->
        Confirm("هل تريد حذف الوصل رقم ${r.id}؟", { scope.launch { dao.deleteReceipt(r.id); del = null } }, { del = null })
    }
}

// ---------- سجل الإضافات ----------
@Composable
fun AdditionsLogScreen(dao: AppDao) {
    val scope = rememberCoroutineScope()
    val all by remember(dao) { dao.additions() }.collectAsState(initial = emptyList())
    var q by remember { mutableStateOf("") }
    var del by remember { mutableStateOf<Addition?>(null) }
    val shown = all.filter { it.productName.contains(q.trim(), true) }

    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Text("سجل الإضافات", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(4.dp))
        OutlinedTextField(q, { q = it }, label = { Text("بحث باسم المنتج") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Column(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
            Row(Modifier.background(Color(0xFFDDEDE8))) {
                Cell("تاريخ العملية", 140.dp, true); Cell("اسم المنتج", 140.dp, true); Cell("الكمية المضافة", 100.dp, true)
                Cell("سعر الشراء وقت الإضافة", 150.dp, true); Cell("سعر البيع وقت الإضافة", 150.dp, true); Cell("حذف", 70.dp, true)
            }
            if (shown.isEmpty()) Text("لا توجد عمليات", Modifier.padding(16.dp))
            LazyColumn {
                items(shown, key = { it.id }) { a ->
                    Row(Modifier.background(Color.White), verticalAlignment = Alignment.CenterVertically) {
                        Cell(dateStr(a.date), 140.dp); Cell(a.productName, 140.dp); Cell(a.qty.toString(), 100.dp)
                        Cell(fmt(a.buyPrice), 150.dp); Cell(fmt(a.sellPrice), 150.dp)
                        TextButton(onClick = { del = a }, modifier = Modifier.width(70.dp), contentPadding = PaddingValues(2.dp)) { Text("حذف", fontSize = 13.sp, color = Color(0xFFC62828)) }
                    }
                    HorizontalDivider(Modifier.width(750.dp))
                }
            }
        }
    }
    del?.let { a ->
        Confirm("حذف سجل هذه العملية؟ لن تتغير كمية المخزون ولا بيانات المنتجات الحالية.",
            { scope.launch { dao.deleteAddition(a.id); del = null } }, { del = null })
    }
}
