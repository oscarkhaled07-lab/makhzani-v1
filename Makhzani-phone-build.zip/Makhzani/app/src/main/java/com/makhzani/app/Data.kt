package com.makhzani.app

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "products", indices = [Index(value = ["name"], unique = true)])
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(collate = ColumnInfo.NOCASE) val name: String,
    val qty: Int,
    val buyPrice: Double,
    val sellPrice: Double,
    val category: String
)

@Entity(tableName = "categories")
data class Category(@PrimaryKey val name: String)

@Entity(tableName = "receipts")
data class Receipt(@PrimaryKey(autoGenerate = true) val id: Long = 0, val date: Long)

// اسم المنتج يُحفظ كنسخة نصية حتى تبقى الوصولات سليمة بعد حذف المنتج
@Entity(
    tableName = "receipt_lines",
    foreignKeys = [ForeignKey(entity = Receipt::class, parentColumns = ["id"], childColumns = ["receiptId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("receiptId")]
)
data class ReceiptLine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val receiptId: Long,
    val productName: String,
    val qty: Int
)

@Entity(tableName = "additions")
data class Addition(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long,
    val productName: String,
    val qty: Int,
    val buyPrice: Double,
    val sellPrice: Double
)

data class ReceiptRow(val id: Long, val date: Long, val cnt: Int)
data class AddLine(val productId: Long, val qty: Int, val buy: Double, val sell: Double)

@Dao
abstract class AppDao {
    @Query("SELECT * FROM products") abstract fun products(): Flow<List<Product>>
    @Query("SELECT * FROM products WHERE id = :id") abstract suspend fun product(id: Long): Product?
    @Query("SELECT COUNT(*) FROM products WHERE name = :name COLLATE NOCASE AND id <> :exceptId")
    abstract suspend fun countName(name: String, exceptId: Long): Int
    @Insert abstract suspend fun insertProduct(p: Product): Long
    @Update abstract suspend fun updateProduct(p: Product)
    @Query("DELETE FROM products WHERE id = :id") abstract suspend fun deleteProduct(id: Long)
    @Insert(onConflict = OnConflictStrategy.IGNORE) abstract suspend fun insertCategory(c: Category)

    @Insert abstract suspend fun insertReceipt(r: Receipt): Long
    @Insert abstract suspend fun insertLines(l: List<ReceiptLine>)
    @Query("SELECT r.id AS id, r.date AS date, (SELECT COUNT(*) FROM receipt_lines l WHERE l.receiptId = r.id) AS cnt FROM receipts r ORDER BY r.id DESC")
    abstract fun receipts(): Flow<List<ReceiptRow>>
    @Query("SELECT * FROM receipt_lines WHERE receiptId = :id ORDER BY id") abstract suspend fun lines(id: Long): List<ReceiptLine>
    @Query("DELETE FROM receipts WHERE id = :id") abstract suspend fun deleteReceipt(id: Long)

    @Query("SELECT * FROM additions ORDER BY date DESC, id DESC") abstract fun additions(): Flow<List<Addition>>
    @Insert abstract suspend fun insertAddition(a: Addition)
    @Query("DELETE FROM additions WHERE id = :id") abstract suspend fun deleteAddition(id: Long)

    /** يعيد نص الخطأ أو null عند النجاح */
    @Transaction
    open suspend fun saveProduct(p: Product): String? {
        val n = p.name.trim()
        if (n.isEmpty()) return "اسم المنتج مطلوب"
        if (p.qty < 0) return "الكمية لا يمكن أن تكون سالبة"
        if (!p.buyPrice.isFinite() || !p.sellPrice.isFinite()) return "السعر غير صحيح"
        if (p.buyPrice < 0 || p.sellPrice < 0) return "السعر لا يمكن أن يكون سالباً"
        if (countName(n, p.id) > 0) return "اسم المنتج موجود مسبقاً"
        val c = p.category.trim()
        if (c.isNotEmpty()) insertCategory(Category(c))
        val q = p.copy(name = n, category = c)
        if (p.id == 0L) insertProduct(q) else updateProduct(q)
        return null
    }

    @Transaction
    open suspend fun saveReceipt(date: Long, items: List<Pair<String, Int>>): Long {
        val id = insertReceipt(Receipt(date = date))
        insertLines(items.map { ReceiptLine(receiptId = id, productName = it.first, qty = it.second) })
        return id
    }

    @Transaction
    open suspend fun confirmAdditions(lines: List<AddLine>, now: Long) {
        for (l in lines) {
            val p = product(l.productId) ?: throw IllegalStateException("أحد المنتجات لم يعد موجوداً")
            updateProduct(p.copy(qty = p.qty + l.qty, buyPrice = l.buy, sellPrice = l.sell))
            insertAddition(Addition(date = now, productName = p.name, qty = l.qty, buyPrice = l.buy, sellPrice = l.sell))
        }
    }
}

@Database(entities = [Product::class, Category::class, Receipt::class, ReceiptLine::class, Addition::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao

    /** رقم الوصل التالي (الترقيم لا يُعاد استخدامه بعد الحذف) */
    fun nextReceiptNo(): Long {
        openHelper.readableDatabase.query("SELECT seq FROM sqlite_sequence WHERE name = 'receipts'").use {
            if (it.moveToFirst()) return it.getLong(0) + 1
        }
        return 1
    }

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "makhzani.db").build().also { inst = it }
        }
    }
}
